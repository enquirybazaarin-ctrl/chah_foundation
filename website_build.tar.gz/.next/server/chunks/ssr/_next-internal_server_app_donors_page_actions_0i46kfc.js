module.exports=[24086,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_donors_page_actions_0i46kfc.js.map