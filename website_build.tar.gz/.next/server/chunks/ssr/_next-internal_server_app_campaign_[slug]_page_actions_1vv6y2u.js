module.exports=[79372,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_campaign_%5Bslug%5D_page_actions_1vv6y2u.js.map