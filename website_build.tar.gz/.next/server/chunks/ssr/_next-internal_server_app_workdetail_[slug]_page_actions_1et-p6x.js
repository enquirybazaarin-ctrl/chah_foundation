module.exports=[72745,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workdetail_%5Bslug%5D_page_actions_1et-p6x.js.map