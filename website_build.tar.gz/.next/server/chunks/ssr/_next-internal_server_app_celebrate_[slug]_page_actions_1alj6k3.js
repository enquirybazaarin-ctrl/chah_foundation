module.exports=[900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_celebrate_%5Bslug%5D_page_actions_1alj6k3.js.map