module.exports=[25902,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_donar_page_actions_0a9wdmc.js.map