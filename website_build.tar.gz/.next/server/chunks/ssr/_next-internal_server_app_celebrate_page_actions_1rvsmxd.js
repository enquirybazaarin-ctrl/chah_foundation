module.exports=[17303,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_celebrate_page_actions_1rvsmxd.js.map