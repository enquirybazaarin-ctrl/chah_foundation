module.exports=[87618,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_overteam_page_actions_0919qrr.js.map