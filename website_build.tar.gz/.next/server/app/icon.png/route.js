var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]__0l8ei7u._.js")
R.c("server/chunks/[root-of-the-server]__0puaa3n._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_1-lsc8h.js")
R.m(72755)
module.exports=R.m(72755).exports
