:HL["/_next/static/chunks/1ahfw7t_n1pt4.css","style"]
:HL["/_next/static/chunks/24-r0rlzu386r.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"vPVZ-3dA0hUs50MpHSxZX"}
