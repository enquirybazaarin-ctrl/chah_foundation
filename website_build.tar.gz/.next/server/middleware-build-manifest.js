globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/YXvSldahvkD93jHMMpJlP/_buildManifest.js",
    "static/YXvSldahvkD93jHMMpJlP/_ssgManifest.js",
    "static/YXvSldahvkD93jHMMpJlP/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0jvhpaew_uadu.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/2qyr2zzqw7k6q.js",
    "static/chunks/2-rtuqsgzmno4.js",
    "static/chunks/turbopack-3l45xn9yrb8wn.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
