globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/sOewUM6tng74921gISYb1/_buildManifest.js",
    "static/sOewUM6tng74921gISYb1/_ssgManifest.js",
    "static/sOewUM6tng74921gISYb1/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/27t_qfc-3_lzs.js",
    "static/chunks/3ertolydtjaa3.js",
    "static/chunks/turbopack-2etuhbohr05qd.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
