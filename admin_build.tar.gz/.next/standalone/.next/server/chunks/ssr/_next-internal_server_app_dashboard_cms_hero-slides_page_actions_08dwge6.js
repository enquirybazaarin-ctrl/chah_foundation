module.exports=[50794,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_cms_hero-slides_page_actions_08dwge6.js.map