module.exports=[79893,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_donations_page_actions_15g32o2.js.map