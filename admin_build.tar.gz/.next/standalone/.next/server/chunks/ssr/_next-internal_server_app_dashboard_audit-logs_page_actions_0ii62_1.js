module.exports=[33895,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_audit-logs_page_actions_0ii62_1.js.map