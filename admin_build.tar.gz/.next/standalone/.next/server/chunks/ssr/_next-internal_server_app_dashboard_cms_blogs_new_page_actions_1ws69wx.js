module.exports=[20232,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_cms_blogs_new_page_actions_1ws69wx.js.map