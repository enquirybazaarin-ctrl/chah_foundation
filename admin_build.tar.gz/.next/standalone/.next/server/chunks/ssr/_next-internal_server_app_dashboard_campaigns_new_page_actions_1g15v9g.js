module.exports=[21964,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_campaigns_new_page_actions_1g15v9g.js.map