module.exports=[23037,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_donors_%5Bid%5D_page_actions_0q09a_r.js.map