module.exports=[70078,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_enquiries_page_actions_1t77d7_.js.map