module.exports=[12449,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_compliance_10be_page_actions_05xmuj0.js.map