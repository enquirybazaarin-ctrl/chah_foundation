module.exports=[15540,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_compliance_page_actions_1b20peg.js.map