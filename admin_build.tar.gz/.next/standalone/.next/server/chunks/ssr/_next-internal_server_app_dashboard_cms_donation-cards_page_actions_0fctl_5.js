module.exports=[64251,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_cms_donation-cards_page_actions_0fctl_5.js.map