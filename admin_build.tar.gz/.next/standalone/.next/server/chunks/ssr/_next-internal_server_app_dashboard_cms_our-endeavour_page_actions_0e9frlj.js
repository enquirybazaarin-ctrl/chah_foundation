module.exports=[59083,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_cms_our-endeavour_page_actions_0e9frlj.js.map