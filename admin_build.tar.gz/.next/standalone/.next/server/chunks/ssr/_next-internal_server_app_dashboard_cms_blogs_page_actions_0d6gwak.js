module.exports=[25222,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_cms_blogs_page_actions_0d6gwak.js.map