module.exports=[79737,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_donors_page_actions_0aln0x2.js.map