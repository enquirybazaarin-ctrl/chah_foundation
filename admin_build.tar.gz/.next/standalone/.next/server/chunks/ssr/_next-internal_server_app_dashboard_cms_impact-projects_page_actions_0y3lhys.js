module.exports=[67473,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_cms_impact-projects_page_actions_0y3lhys.js.map