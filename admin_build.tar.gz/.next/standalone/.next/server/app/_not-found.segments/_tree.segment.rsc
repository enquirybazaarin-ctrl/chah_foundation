:HL["/_next/static/chunks/3d-1vk5hzu5rq.css","style"]
:HL["/_next/static/chunks/269xwytsobm83.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"sOewUM6tng74921gISYb1"}
